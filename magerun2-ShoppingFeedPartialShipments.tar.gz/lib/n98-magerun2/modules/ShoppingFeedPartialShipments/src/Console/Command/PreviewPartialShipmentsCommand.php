<?php

namespace Apikom\ShoppingFeedPartialShipments\Console\Command;

use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Sales\Api\Data\OrderItemInterface as SalesOrderItemInterface;
use Magento\Sales\Api\OrderItemRepositoryInterface as SalesOrderItemRepositoryInterface;
use N98\Magento\Command\AbstractMagentoCommand;
use ShoppingFeed\Manager\Api\Account\StoreRepositoryInterface;
use ShoppingFeed\Manager\Api\Data\Account\StoreInterface;
use ShoppingFeed\Manager\Api\Data\Marketplace\Order\ItemInterface as MarketplaceItemInterface;
use ShoppingFeed\Manager\Api\Data\Marketplace\OrderInterface as MarketplaceOrderInterface;
use ShoppingFeed\Manager\Model\Marketplace\Order\Manager as MarketplaceOrderManager;
use ShoppingFeed\Manager\Model\ResourceModel\Marketplace\Order\CollectionFactory as MarketplaceOrderCollectionFactory;
use ShoppingFeed\Manager\Model\Sales\Order\ConfigInterface as OrderConfigInterface;
use ShoppingFeed\Manager\Model\Sales\Order\Shipment\Track as ShipmentTrack;
use ShoppingFeed\Manager\Model\Sales\Order\Shipment\Track\Collector as ShipmentTrackCollector;
use Symfony\Component\Console\Helper\Table;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Shows what the partial shipments of marketplace orders would send to Shopping Feed, without sending anything.
 *
 * The items to send are computed by the module itself (MarketplaceOrderManager::notifyStoreOrderPartialShipments()),
 * on a copy of the manager whose API call is replaced by a printout.
 */
class PreviewPartialShipmentsCommand extends AbstractMagentoCommand
{
    protected function configure(): void
    {
        $this
            ->setName('shopping-feed:partial-shipments:preview')
            ->setDescription('Show what the partial shipments of marketplace orders would send to Shopping Feed')
            ->addOption(
                'order',
                null,
                InputOption::VALUE_REQUIRED | InputOption::VALUE_IS_ARRAY,
                'Marketplace order number (repeat the option for several orders)'
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->detectMagento($output, true);

        if (!$this->initMagento()) {
            return 1;
        }

        $orderNumbers = array_values(array_unique($input->getOption('order')));

        if (empty($orderNumbers)) {
            $output->writeln('<error>The --order option is required.</error>');

            return 1;
        }

        $objectManager = $this->getObjectManager();

        $marketplaceOrders = $objectManager->get(MarketplaceOrderCollectionFactory::class)
            ->create()
            ->addFieldToFilter('marketplace_order_number', [ 'in' => $orderNumbers ]);

        if ($marketplaceOrders->count() === 0) {
            $output->writeln('<error>No marketplace order found.</error>');

            return 1;
        }

        $storeRepository = $objectManager->get(StoreRepositoryInterface::class);
        $orderGeneralConfig = $objectManager->get(OrderConfigInterface::class);
        $trackCollector = $objectManager->get(ShipmentTrackCollector::class);
        $manager = $this->getRecordingManager($objectManager->get(MarketplaceOrderManager::class));

        $notifyPartialShipments = new \ReflectionMethod(
            MarketplaceOrderManager::class,
            'notifyStoreOrderPartialShipments'
        );

        $notifyPartialShipments->setAccessible(true);

        $shippedRows = [];
        $sentRows = [];

        /** @var MarketplaceOrderInterface $marketplaceOrder */
        foreach ($marketplaceOrders as $marketplaceOrder) {
            $orderNumber = $marketplaceOrder->getMarketplaceOrderNumber();
            $salesOrderId = (int) $marketplaceOrder->getSalesOrderId();

            if ($salesOrderId <= 0) {
                $output->writeln(sprintf('<comment>%s: not imported.</comment>', $orderNumber));
                continue;
            }

            /** @var StoreInterface $store */
            $store = $storeRepository->getById($marketplaceOrder->getStoreId());

            if (!$orderGeneralConfig->shouldSyncPartialShipments($store)) {
                $output->writeln(
                    sprintf(
                        '<comment>%s: partial shipments are not synchronized for this store.</comment>',
                        $orderNumber
                    )
                );
            }

            // Like the module does, but without excluding the shipments that were already synchronized.
            $trackCollector->setExcludedShipmentIds([]);
            $salesOrderShipmentTracks = $trackCollector->getOrdersShipmentTracks([ $salesOrderId ]);
            $salesOrderItemShoppingFeedIds = $this->getSalesOrderItemShoppingFeedIds($salesOrderId);

            $shipmentIds = [];

            /** @var ShipmentTrack $shipmentTrack */
            foreach ($salesOrderShipmentTracks[$salesOrderId] ?? [] as $shipmentTrack) {
                $shipment = $shipmentTrack->getShipment();

                if (!$shipment || isset($shipmentIds[$shipment->getId()])) {
                    continue;
                }

                $shipmentIds[$shipment->getId()] = true;

                foreach ($shipment->getItems() as $shipmentItem) {
                    $orderItemId = (int) $shipmentItem->getOrderItemId();

                    $shippedRows[] = [
                        $orderNumber,
                        $shipment->getIncrementId(),
                        $shipmentItem->getSku(),
                        sprintf('%.2f', $shipmentItem->getPrice()),
                        $salesOrderItemShoppingFeedIds[$orderItemId] ?? '-',
                        (float) $shipmentItem->getQty(),
                    ];
                }
            }

            if (empty($shipmentIds)) {
                $output->writeln(sprintf('<comment>%s: no shipment (with a tracking number).</comment>', $orderNumber));
                continue;
            }

            $manager->calls = [];

            $notifyPartialShipments->invoke(
                $manager,
                [ $marketplaceOrder ],
                $salesOrderShipmentTracks,
                $salesOrderItemShoppingFeedIds,
                $store
            );

            if (empty($manager->calls)) {
                $output->writeln(
                    sprintf(
                        '<comment>%s: nothing would be sent yet (no tracking number, and the syncing delay has not passed).</comment>',
                        $orderNumber
                    )
                );
            }

            foreach ($manager->calls as $call) {
                foreach ($call['items'] as $item) {
                    $sentRows[] = [
                        $orderNumber,
                        $call['shipment'],
                        $call['carrier'],
                        $call['tracking_number'],
                        $item['id'],
                        $item['quantity'],
                    ];
                }
            }
        }

        $output->writeln('');
        $output->writeln('<info>Shipped in Magento:</info>');

        (new Table($output))
            ->setHeaders([ 'Order number', 'Shipment', 'SKU', 'Unit price', 'Shopping Feed item ID', 'Quantity' ])
            ->setRows($shippedRows)
            ->render();

        $output->writeln('');
        $output->writeln('<info>Would be sent to Shopping Feed:</info>');

        (new Table($output))
            ->setHeaders(
                [ 'Order number', 'Shipment', 'Carrier', 'Tracking number', 'Shopping Feed item ID', 'Quantity' ]
            )
            ->setRows($sentRows)
            ->render();

        return 0;
    }

    /**
     * Same mapping as the one made by the module before synchronizing partial shipments.
     *
     * @param int $salesOrderId
     * @return int[]
     */
    private function getSalesOrderItemShoppingFeedIds($salesOrderId)
    {
        $objectManager = $this->getObjectManager();

        $salesOrderItems = $objectManager->get(SalesOrderItemRepositoryInterface::class)->getList(
            $objectManager->get(SearchCriteriaBuilder::class)
                ->addFilter(SalesOrderItemInterface::ORDER_ID, $salesOrderId)
                ->create()
        );

        $shoppingFeedIds = [];

        foreach ($salesOrderItems->getItems() as $salesOrderItem) {
            if (
                $sfItemId = (int) $salesOrderItem->getProductOptionByCode(
                    MarketplaceItemInterface::ORDER_ITEM_OPTION_CODE_SHOPPING_FEED_ITEM_ID
                )
            ) {
                $shoppingFeedIds[(int) $salesOrderItem->getItemId()] = $sfItemId;
            }
        }

        return $shoppingFeedIds;
    }

    /**
     * Returns a copy of the manager that records the partial shipments instead of sending them to Shopping Feed.
     *
     * @param MarketplaceOrderManager $manager
     * @return MarketplaceOrderManager
     */
    private function getRecordingManager(MarketplaceOrderManager $manager)
    {
        $recordingManager = new class extends MarketplaceOrderManager {
            /**
             * @var array[]
             */
            public $calls = [];

            public function __construct()
            {
            }

            public function notifyStoreOrderPartialShipment(
                MarketplaceOrderInterface $order,
                $shipmentId,
                ShipmentTrack $shipmentTrack,
                array $items,
                StoreInterface $store
            ) {
                $shipment = $shipmentTrack->getShipment();

                $this->calls[] = [
                    'shipment' => $shipment ? $shipment->getIncrementId() : $shipmentId,
                    'carrier' => $shipmentTrack->getCarrierTitle(),
                    'tracking_number' => $shipmentTrack->getTrackingNumber(),
                    'items' => $items,
                ];
            }
        };

        foreach ((new \ReflectionClass(MarketplaceOrderManager::class))->getProperties() as $property) {
            if (!$property->isStatic()) {
                $property->setAccessible(true);
                $property->setValue($recordingManager, $property->getValue($manager));
            }
        }

        return $recordingManager;
    }
}
