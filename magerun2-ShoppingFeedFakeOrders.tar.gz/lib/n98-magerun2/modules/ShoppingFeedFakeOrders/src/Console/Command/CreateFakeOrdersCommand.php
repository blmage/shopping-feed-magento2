<?php

namespace Apikom\ShoppingFeedFakeOrders\Console\Command;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\ResourceConnection;
use Magento\Framework\Exception\NoSuchEntityException;
use N98\Magento\Command\AbstractMagentoCommand;
use ShoppingFeed\Manager\Api\Account\StoreRepositoryInterface;
use ShoppingFeed\Manager\Api\Data\Account\StoreInterface;
use ShoppingFeed\Manager\Api\Data\Marketplace\Order\AddressInterface;
use ShoppingFeed\Manager\Api\Data\Marketplace\Order\AddressInterfaceFactory;
use ShoppingFeed\Manager\Api\Data\Marketplace\Order\ItemInterfaceFactory;
use ShoppingFeed\Manager\Api\Data\Marketplace\OrderInterface;
use ShoppingFeed\Manager\Api\Data\Marketplace\OrderInterfaceFactory;
use ShoppingFeed\Manager\Api\Marketplace\Order\AddressRepositoryInterface;
use ShoppingFeed\Manager\Api\Marketplace\Order\ItemRepositoryInterface;
use ShoppingFeed\Manager\Api\Marketplace\OrderRepositoryInterface;
use ShoppingFeed\Manager\Model\Sales\Order\Item\PriceAllocator;
use Symfony\Component\Console\Helper\Table;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

/**
 * Creates fake Shopping Feed orders whose unit prices have 4 decimals, to exercise the rounding modes of the import.
 *
 * The orders get Shopping Feed IDs from FAKE_ID_BASE upwards, a range no real order can reach,
 * so that the acknowledgements sent after their import can not affect any real order.
 *
 * The IDs stay below FAKE_ID_LIMIT (2^53): Magento writes BIGINT values that it reads back as strings
 * through a float, and larger IDs would then be rounded (and collide with each other).
 *
 * They can be removed (with their addresses, items, logs and tickets) with:
 * DELETE FROM sfm_marketplace_order WHERE shopping_feed_order_id >= 9000000000000000;
 */
class CreateFakeOrdersCommand extends AbstractMagentoCommand
{
    const FAKE_ID_BASE = 9000000000000000;
    const FAKE_ID_LIMIT = 9007199254740992;

    const TOTALS_AUTO = 'auto';
    const TOTALS_LINE = 'line';
    const TOTALS_ORDER = 'order';

    /**
     * The lines of each scenario: unit price (with 4 decimals) and quantity.
     */
    const SCENARIOS = [
        // Line or order rounding: 25.00 / Magento alone: 24.99
        'single_line' => [ [ '8.3333', 3 ] ],
        // Line or order rounding: 333.33 / Magento alone: 333.30
        'ten_units' => [ [ '33.3333', 10 ] ],
        // Line or order rounding: 3.02 / Magento alone: 3.03
        'half_cent_tie' => [ [ '1.0050', 3 ] ],
        // Line rounding: 20.02 / Order rounding: 20.01 / Magento alone: 20.02
        'single_units' => [ [ '10.0050', 1 ], [ '10.0050', 1 ] ],
        // Line rounding: 27.51 / Order rounding: 27.50 / Magento alone: 27.49
        'two_lines' => [ [ '8.3333', 3 ], [ '1.2525', 2 ] ],
        // Line or order rounding: 166.61 / Magento alone: 166.58
        'mixed' => [ [ '19.9900', 7 ], [ '2.4999', 2 ], [ '10.0049', 2 ], [ '0.3333', 5 ] ],
        // 36.90 everywhere
        'whole_cents' => [ [ '12.3000', 3 ] ],
    ];

    /**
     * @var ResourceConnection
     */
    private $resourceConnection;

    /**
     * @var OrderInterfaceFactory
     */
    private $orderFactory;

    /**
     * @var OrderRepositoryInterface
     */
    private $orderRepository;

    /**
     * @var AddressInterfaceFactory
     */
    private $addressFactory;

    /**
     * @var AddressRepositoryInterface
     */
    private $addressRepository;

    /**
     * @var ItemInterfaceFactory
     */
    private $itemFactory;

    /**
     * @var ItemRepositoryInterface
     */
    private $itemRepository;

    protected function configure(): void
    {
        $this
            ->setName('shopping-feed:fake-orders:create')
            ->setDescription('Create fake Shopping Feed orders with 4-decimal unit prices')
            ->addOption(
                'store',
                null,
                InputOption::VALUE_REQUIRED,
                'Shopping Feed account store ID (sfm_account_store.store_id)'
            )
            ->addOption(
                'sku',
                null,
                InputOption::VALUE_REQUIRED | InputOption::VALUE_IS_ARRAY,
                'SKU of an in-stock simple product (repeat the option to use several products)'
            )
            ->addOption(
                'marketplace',
                null,
                InputOption::VALUE_REQUIRED | InputOption::VALUE_IS_ARRAY,
                'Marketplace name (repeat the option for several marketplaces)',
                [ 'retif', 'retif_total', 'retif_default' ]
            )
            ->addOption(
                'scenario',
                null,
                InputOption::VALUE_REQUIRED | InputOption::VALUE_IS_ARRAY,
                'Scenario (repeat the option for several scenarios): ' . implode(', ', array_keys(self::SCENARIOS)),
                array_keys(self::SCENARIOS)
            )
            ->addOption(
                'totals',
                null,
                InputOption::VALUE_REQUIRED,
                'How the marketplace rounds its totals: "line", "order", or "auto" (from the rounding mode)',
                self::TOTALS_AUTO
            )
            ->addOption(
                'shipping-amount',
                null,
                InputOption::VALUE_REQUIRED,
                'Shipping amount of the orders',
                '0'
            )
            ->addOption(
                'test',
                null,
                InputOption::VALUE_NONE,
                'Flag the orders as test orders'
            );
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $this->detectMagento($output, true);

        if (!$this->initMagento()) {
            return 1;
        }

        $objectManager = $this->getObjectManager();

        $this->resourceConnection = $objectManager->get(ResourceConnection::class);
        $this->orderFactory = $objectManager->get(OrderInterfaceFactory::class);
        $this->orderRepository = $objectManager->get(OrderRepositoryInterface::class);
        $this->addressFactory = $objectManager->get(AddressInterfaceFactory::class);
        $this->addressRepository = $objectManager->get(AddressRepositoryInterface::class);
        $this->itemFactory = $objectManager->get(ItemInterfaceFactory::class);
        $this->itemRepository = $objectManager->get(ItemRepositoryInterface::class);

        $storeId = (int) $input->getOption('store');
        $skus = array_values(array_unique($input->getOption('sku')));
        $marketplaces = array_values(array_unique($input->getOption('marketplace')));
        $scenarios = array_values(array_unique($input->getOption('scenario')));
        $totals = (string) $input->getOption('totals');
        $shippingAmount = round((float) $input->getOption('shipping-amount'), 2);
        $isTest = (bool) $input->getOption('test');

        if ($storeId <= 0) {
            $output->writeln('<error>The --store option is required.</error>');

            return 1;
        }

        if (empty($skus)) {
            $output->writeln('<error>The --sku option is required.</error>');

            return 1;
        }

        $unknownScenarios = array_diff($scenarios, array_keys(self::SCENARIOS));

        if (!empty($unknownScenarios)) {
            $output->writeln(sprintf('<error>Unknown scenario(s): %s.</error>', implode(', ', $unknownScenarios)));

            return 1;
        }

        if (!in_array($totals, [ self::TOTALS_AUTO, self::TOTALS_LINE, self::TOTALS_ORDER ], true)) {
            $output->writeln(sprintf('<error>Unknown totals rounding: "%s".</error>', $totals));

            return 1;
        }

        try {
            /** @var StoreInterface $store */
            $store = $objectManager->get(StoreRepositoryInterface::class)->getById($storeId);
        } catch (NoSuchEntityException $e) {
            $output->writeln(sprintf('<error>Unknown Shopping Feed account store: %d.</error>', $storeId));

            return 1;
        }

        $productRepository = $objectManager->get(ProductRepositoryInterface::class);

        foreach ($skus as $sku) {
            try {
                $productRepository->get($sku);
            } catch (NoSuchEntityException $e) {
                $output->writeln(sprintf('<error>Unknown SKU: "%s".</error>', $sku));

                return 1;
            }
        }

        $priceAllocator = $objectManager->get(PriceAllocator::class);
        $currencyCode = $store->getBaseStore()->getCurrentCurrencyCode();
        $offset = $this->getNextFakeIdOffset();
        $rows = [];

        foreach ($marketplaces as $marketplace) {
            $roundingMode = $priceAllocator->getMarketplaceRoundingMode($store, $marketplace);
            $marketplaceTotals = $totals;

            if (self::TOTALS_AUTO === $marketplaceTotals) {
                $marketplaceTotals = (PriceAllocator::ROUNDING_MODE_ORDER_TOTAL === $roundingMode)
                    ? self::TOTALS_ORDER
                    : self::TOTALS_LINE;
            }

            foreach ($scenarios as $scenario) {
                $lines = self::SCENARIOS[$scenario];
                $productAmount = $this->getMarketplaceProductAmount($lines, $marketplaceTotals);

                $orderNumber = $this->createOrder(
                    $store,
                    $marketplace,
                    $scenario,
                    $lines,
                    $skus,
                    $offset++,
                    $productAmount,
                    $shippingAmount,
                    $currencyCode,
                    $isTest
                );

                $rows[] = [
                    $orderNumber,
                    $marketplace,
                    $roundingMode,
                    $marketplaceTotals,
                    implode(
                        ' + ',
                        array_map(
                            function (array $line) {
                                return $line[1] . ' x ' . $line[0];
                            },
                            $lines
                        )
                    ),
                    sprintf('%.2f', $productAmount + $shippingAmount),
                    sprintf('%.2f', $this->getMagentoProductAmount($lines) + $shippingAmount),
                ];
            }
        }

        $table = new Table($output);

        $table->setHeaders(
            [
                'Order number',
                'Marketplace',
                'Rounding mode',
                'Totals',
                'Lines',
                'Marketplace total',
                'Magento alone',
            ]
        );

        $table->setRows($rows);
        $table->render();

        $output->writeln(sprintf('<info>%d fake order(s) created.</info>', count($rows)));

        return 0;
    }

    /**
     * @return int
     */
    private function getNextFakeIdOffset()
    {
        $connection = $this->resourceConnection->getConnection();
        $tableName = $this->resourceConnection->getTableName('sfm_marketplace_order');

        $maxId = $connection->fetchOne(
            $connection->select()
                ->from($tableName, [ 'MAX(shopping_feed_order_id)' ])
                ->where('shopping_feed_order_id >= ?', self::FAKE_ID_BASE)
                ->where('shopping_feed_order_id < ?', self::FAKE_ID_LIMIT)
        );

        return empty($maxId) ? 1 : (int) $maxId - self::FAKE_ID_BASE + 1;
    }

    /**
     * @param string $price
     * @param int $quantity
     * @return int The total of the line, in ten-thousandths.
     */
    private function getLineTotal($price, $quantity)
    {
        return (int) round((float) $price * 10000) * $quantity;
    }

    /**
     * @param array $lines
     * @param string $totals
     * @return float
     */
    private function getMarketplaceProductAmount(array $lines, $totals)
    {
        $totalInCents = 0;

        if (self::TOTALS_LINE === $totals) {
            foreach ($lines as [ $price, $quantity ]) {
                $totalInCents += intdiv($this->getLineTotal($price, $quantity) + 50, 100);
            }
        } else {
            $total = 0;

            foreach ($lines as [ $price, $quantity ]) {
                $total += $this->getLineTotal($price, $quantity);
            }

            $totalInCents = intdiv($total + 50, 100);
        }

        return $totalInCents / 100;
    }

    /**
     * The product amount computed by Magento, which rounds unit prices before multiplying them by quantities.
     *
     * @param array $lines
     * @return float
     */
    private function getMagentoProductAmount(array $lines)
    {
        $totalInCents = 0;

        foreach ($lines as [ $price, $quantity ]) {
            $totalInCents += intdiv($this->getLineTotal($price, 1) + 50, 100) * $quantity;
        }

        return $totalInCents / 100;
    }

    /**
     * @param string $type
     * @return AddressInterface
     */
    private function createAddress($type)
    {
        $address = $this->addressFactory->create();

        $address->setType($type);
        $address->setFirstName('Fake');
        $address->setLastName('Order');
        $address->setCompany('');
        $address->setStreet('1 rue du Test');
        $address->setProvince(null);
        $address->setPostalCode('75001');
        $address->setCity('Paris');
        $address->setCountryCode('FR');
        $address->setPhone('0102030405');
        $address->setMobilePhone('');
        $address->setEmail('fake-order@example.com');
        $address->setRelayPointId('');
        $address->setMiscData('');

        return $address;
    }

    /**
     * @param StoreInterface $store
     * @param string $marketplace
     * @param string $scenario
     * @param array $lines
     * @param string[] $skus
     * @param int $offset
     * @param float $productAmount
     * @param float $shippingAmount
     * @param string $currencyCode
     * @param bool $isTest
     * @return string The order number.
     * @throws \Exception
     */
    private function createOrder(
        StoreInterface $store,
        $marketplace,
        $scenario,
        array $lines,
        array $skus,
        $offset,
        $productAmount,
        $shippingAmount,
        $currencyCode,
        $isTest
    ) {
        $now = gmdate('Y-m-d H:i:s');
        $orderNumber = sprintf('FAKE-%d-%s', $offset, $scenario);

        $order = $this->orderFactory->create();
        $order->setStoreId($store->getId());
        $order->setShoppingFeedOrderId(self::FAKE_ID_BASE + $offset);
        $order->setMarketplaceOrderNumber($orderNumber);
        $order->setShoppingFeedMarketplaceId(0);
        $order->setMarketplaceName($marketplace);
        $order->setShoppingFeedStatus(OrderInterface::STATUS_WAITING_SHIPMENT);
        $order->setIsTest($isTest);
        $order->setIsFulfilled(false);
        $order->setHasNonNotifiableShipment(false);
        $order->setImportRemainingTryCount(OrderInterface::DEFAULT_IMPORT_TRY_COUNT);
        $order->setCurrencyCode($currencyCode);
        $order->setProductAmount($productAmount);
        $order->setShippingAmount($shippingAmount);
        $order->setFeesAmount(0.0);
        $order->setTotalAmount(round($productAmount + $shippingAmount, 2));
        $order->setPaymentMethod('fake');
        $order->setShipmentCarrier('Fake carrier');
        $order->setCreatedAt($now);
        $order->setUpdatedAt($now);
        $order->setFetchedAt($now);

        $items = [];

        foreach ($lines as $index => [ $price, $quantity ]) {
            $item = $this->itemFactory->create();
            $item->setShoppingFeedItemId(self::FAKE_ID_BASE + $offset * 100 + $index + 1);
            $item->setReference($skus[$index % count($skus)]);
            $item->setQuantity($quantity);
            $item->setPrice((float) $price);
            $items[] = $item;
        }

        $connection = $this->resourceConnection->getConnection();
        $connection->beginTransaction();

        try {
            $this->orderRepository->save($order);
            $orderId = $order->getId();

            $this->addressRepository->save(
                $this->createAddress(AddressInterface::TYPE_BILLING)->setOrderId($orderId)
            );

            $this->addressRepository->save(
                $this->createAddress(AddressInterface::TYPE_SHIPPING)->setOrderId($orderId)
            );

            foreach ($items as $item) {
                $this->itemRepository->save($item->setOrderId($orderId));
            }

            $connection->commit();
        } catch (\Exception $e) {
            $connection->rollBack();

            throw $e;
        }

        return $orderNumber;
    }
}
